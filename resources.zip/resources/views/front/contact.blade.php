@extends('front.layouts.master')
@section('content')
@include('front.components.breadcrumb')
    @include('front.components.contact')
    </div>
@endsection
