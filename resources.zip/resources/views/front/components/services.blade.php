    <!-- service area start -->
    <div class="service-area pd-top-120 pd-bottom-90">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6">
                    <div class="single-service-inner style-hover-base text-center">
                        <div class="icon-box">
                            <i class="icomoon-profile"></i>
                        </div>
                        <div class="details">
                            <h3><a href="service-details.html">Web design</a></h3>
                            <p>Curabitur ullamcorper ultricies nisiam tiamns rhoncus. Maecenas tempus tellus endimentum </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="single-service-inner style-hover-base text-center">
                        <div class="icon-box">
                            <i class="icomoon-layer"></i>
                        </div>
                        <div class="details">
                            <h3><a href="service-details.html">Web design</a></h3>
                            <p>Curabitur ullamcorper ultricies nisiam tiamns rhoncus. Maecenas tempus tellus endimentum </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="single-service-inner style-hover-base text-center">
                        <div class="icon-box">
                            <i class="icomoon-application"></i>
                        </div>
                        <div class="details">
                            <h3><a href="service-details.html">Web design</a></h3>
                            <p>Curabitur ullamcorper ultricies nisiam tiamns rhoncus. Maecenas tempus tellus endimentum </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="single-service-inner style-hover-base text-center">
                        <div class="icon-box">
                            <i class="icomoon-cloud-data"></i>
                        </div>
                        <div class="details">
                            <h3><a href="service-details.html">Web design</a></h3>
                            <p>Curabitur ullamcorper ultricies nisiam tiamns rhoncus. Maecenas tempus tellus endimentum </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="single-service-inner style-hover-base text-center">
                        <div class="icon-box">
                            <i class="icomoon-megaphone"></i>
                        </div>
                        <div class="details">
                            <h3><a href="service-details.html">Web design</a></h3>
                            <p>Curabitur ullamcorper ultricies nisiam tiamns rhoncus. Maecenas tempus tellus endimentum </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="single-service-inner style-hover-base text-center">
                        <div class="icon-box">
                            <i class="icomoon-lock"></i>
                        </div>
                        <div class="details">
                            <h3><a href="service-details.html">Web design</a></h3>
                            <p>Curabitur ullamcorper ultricies nisiam tiamns rhoncus. Maecenas tempus tellus endimentum </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="single-service-inner style-hover-base text-center">
                        <div class="icon-box">
                            <i class="icomoon-magnifiying-glass"></i>
                        </div>
                        <div class="details">
                            <h3><a href="service-details.html">Web design</a></h3>
                            <p>Curabitur ullamcorper ultricies nisiam tiamns rhoncus. Maecenas tempus tellus endimentum </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="single-service-inner style-hover-base text-center">
                        <div class="icon-box">
                            <i class="icomoon-computer"></i>
                        </div>
                        <div class="details">
                            <h3><a href="service-details.html">Web design</a></h3>
                            <p>Curabitur ullamcorper ultricies nisiam tiamns rhoncus. Maecenas tempus tellus endimentum </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="single-service-inner style-hover-base text-center">
                        <div class="icon-box">
                            <i class="icomoon-deep-learning"></i>
                        </div>
                        <div class="details">
                            <h3><a href="service-details.html">Web design</a></h3>
                            <p>Curabitur ullamcorper ultricies nisiam tiamns rhoncus. Maecenas tempus tellus endimentum </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- service area end -->