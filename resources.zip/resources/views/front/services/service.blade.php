@extends('front.layouts.master')
@section('content')
@include('front.components.breadcrumb')
@include('front.components.services')
@endsection
