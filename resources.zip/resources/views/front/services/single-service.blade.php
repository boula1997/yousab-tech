@extends('front.layouts.master')
@section('content')
@include('front.components.single-service')

@endsection
