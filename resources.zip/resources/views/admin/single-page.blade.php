<div id="page-inner">
    <div class="row">
        <div class="col-md-12">
            <h2>BLANK PAGE </h2>
        </div>
    </div>
    <!-- /. ROW  -->
    <hr />

    <!-- /. ROW  -->
</div>